# https://ghproxy.com/https://github.com/unlone/tar/raw/master/2.tar

#!/bin/bash  

# read -p "打包文件名:" input_var  
# echo "" $input_var

# # tar -cvf ./$input_var.tar ./
# tar -zxvf  ./$input_var.tar -C ./demo

read -p "请的文件链接地址:" input_var1 

echo https://ghproxy.com/$input_var1
read -p "请的项目重命名:" input_var2
wget -O $input_var2.tar  https://ghproxy.com/$input_var1
read -p "请的解压目录:" input_var3
mkdir $input_var3
tar -zxvf  ./$input_var2.tar -C ./$input_var3
rm -rf $input_var2.tar





#!/bin/bash  

# read -p "打包文件名:" input_var  
# echo "" $input_var

# # tar -cvf ./$input_var.tar ./
# tar -zxvf  ./$input_var.tar -C ./demo

read -p "请打包的项目名称:" input_var1 


if [ ! $input_var1 ]
then
  echo "####### 请打包的项目名称 #######"
  exit;
fi
 read -p "请输入commit值:" input_var2
if [ ! $input_var2 ]
then
  echo "####### 请输入commit值 #######"
  exit;
fi
 
#给出一个默认的项目路径
path="./"
 
# case "$1" in
#   "p")
#   echo "PC项目"
#   path="/Users/duodian/Desktop/work/web-pc"
#   ;;
#   "m")
#   echo "小程序项目"
#   path="/Users/duodian/Desktop/work/miniProgram"
#   ;;
#   "h")
#   echo "H5项目"
#   path="/Users/duodian/Desktop/work/web-h5"
#   ;;
#   "c")
#   echo "后台项目"
#   path="/Users/duodian/Desktop/work/circleManAdmin"
#   ;;
# esac
 
#先进入项目当中
 
cd $path
 
echo "####### 进入自己的项目 #######"
 
ls
 



echo "打包开始"
tar -cvf ./$input_var1.tar ./
echo "打包完成"

 echo "开始执行git命令"
git add $input_var1.tar
 
git status
 
#写个sleep 1s 是为了解决并发导致卡壳
 
sleep 1s
 
echo "####### 添加文件 #######"
 
git commit -m "$input_var2"
 
echo "####### commit #######"
 
sleep 1s
 
echo "####### 开始推送 #######"
# read -p "请输入自己提交代码的分支:" input_var3
# if [ ! $input_var3 ]
# then
#   echo "####### 请输入自己提交代码的分支 #######"
#   exit;
# fi
 
# git push origin "$input_var3"
git push origin master -f
 
echo "####### 推送成功 #######"
